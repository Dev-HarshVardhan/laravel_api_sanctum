<?php

namespace Database\Seeders;


use App\Models\Demo;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
       Demo::factory()->count(10)->create();

       Demo::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]);
    }
}
