<?php

use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\BlogController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    echo '<h1>Welcome To Home Page</h1>';
});



Route::resource('blog',BlogController::class);




Route::post('insert',[UserController::class,'index']);
Route::get('register',[UserController::class,'create']);
Route::post('login',[UserController::class,'login']);

Route::get('dashboard',[UserController::class,'dash']);
Route::get('logout',[UserController::class,'logout']);


Route::get('blog',[BlogController::class,'index']);
Route::get('show',[BlogController::class,'show']);
Route::post('store',[BlogController::class,'store']);
Route::get('demo',[ProductController::class,'demo']);

Route::get('dashboard',function(){
    return view('dashboard');
});