<?php
use App\Http\Controllers\Api\ProductController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;



Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::get('products', [ProductController::class, 'index']);
Route::post('products', [ProductController::class, 'store']);
Route::put('products', [ProductController::class, 'update']);
Route::delete('products/{id}', [ProductController::class, 'destory']);
Route::get('products/{id}', [ProductController::class, 'show']);
Route::post('products_login', [ProductController::class, 'login']);
Route::post('signup', [ProductController::class, 'signup']);



Route::group(['middleware' => 'auth:sanctum'], function(){

});