@extends('master')

@section('shubham')
<h1>Welcome to Dashboard Shubham</h1>
@endsection