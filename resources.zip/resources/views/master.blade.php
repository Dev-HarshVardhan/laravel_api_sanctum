@include('header')

@yield('shubham')

@include('footer')