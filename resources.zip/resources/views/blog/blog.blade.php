<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create a Blog Post</title>
</head>

<body>

    <h1>Create a New Blog Post</h1>
    @if(session()->has('message'))
    <div class="alert {{ session('alert alert-success') }}">
        {{ session('message') }}
    </div>
    @endif

    <form action="{{ url('store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <label for="title">Name:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="image">Upload an Image:</label>
        <input type="file" id="image" name="img" accept="image/*"><br><br>

        <input type="submit" value="Submit Post">
    </form>

    <h2>Show The Blog Data</h2>
    <table border="1" rules="all">
        <thead>
            <tr>
                <th>Sr no</th>
                <th>Name</th>
                <th>img</th>
            </tr>
        </thead>
        <tbody>
            @foreach($blogs as $blog)
            <tr>
                <td>{{ $blog->id }}</td>
                <td>{{ $blog->name }}</td>
                <td><img src="public/{{ $blog->img }}" alt="" height="50px"></td>
            </tr>

            @endforeach


        </tbody>
    </table>

</body>

</html>