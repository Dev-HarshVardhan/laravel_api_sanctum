

<?php $__env->startSection('shubham'); ?>
<h1>Welcome to Dashboard Shubham</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\laravel-11\demo\resources\views/dashboard.blade.php ENDPATH**/ ?>