<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create a Blog Post</title>
</head>

<body>

    <h1>Create a New Blog Post</h1>
    <?php if(session()->has('message')): ?>
    <div class="alert <?php echo e(session('alert alert-success')); ?>">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>

    <form action="<?php echo e(url('store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="title">Name:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="image">Upload an Image:</label>
        <input type="file" id="image" name="img" accept="image/*"><br><br>

        <input type="submit" value="Submit Post">
    </form>

    <h2>Show The Blog Data</h2>
    <table border="1" rules="all">
        <thead>
            <tr>
                <th>Sr no</th>
                <th>Name</th>
                <th>img</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($blog->id); ?></td>
                <td><?php echo e($blog->name); ?></td>
                <td><img src="public/<?php echo e($blog->img); ?>" alt="" height="50px"></td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
    </table>

</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\laravel-11\demo\resources\views/blog/blog.blade.php ENDPATH**/ ?>