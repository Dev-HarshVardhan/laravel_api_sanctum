<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class demo extends Model
{
    protected $table = "demo";

    protected $fillable = [
        'name',
        'email',
        'mobile',
    ];
}
