<?php  

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth; // Corrected import

class UserController extends Controller 
{
    public function index(Request $request)
    {
        $data = $request->all();
        $user = User::create($data); 

        if ($user) {
            return redirect()->to('register');
        } else {
            return redirect()->to('register'); 
        }
    }

    public function create()
    {
        return view('login');
    }

    public function dash()
    {
       if(Auth::check()){
        return view('dashboard');
       }else{
        return redirect()->to('register');
       }
                    
    }

    public function login(Request $request)
    {
        $data = $request->validate([
            'email'    => 'required|email',
            'password' => 'required', 
        ]);

        if (Auth::attempt(['email' => $data['email'], 'password' => $data['password']])) {
            return redirect()->to('dashboard');
        } else {
            return redirect()->to('register');
        }
    }

    public function logout(){
        Auth::logout();
        return redirect()->to('register');
    }
}
