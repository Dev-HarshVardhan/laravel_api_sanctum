<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProductResource;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    public function index()
    {
        $products = DB::table('product')->get();
    
        if ($products->isEmpty()) {
            return response()->json(['message' => 'No Record Found'], 404); 
        } else {
            return ProductResource::collection($products);
        }
    }
    
    
   public function store(Request $request){

    $rul=array(
        "name"=> "required|min:5",
        "email" => "email|required",
        "password" => "required|min:6"
    );
    $validation=Validator::make($request->all(), $rul);

    if($validation->fails()){
        return $validation->errors();
    }else{
        $products=DB::table('product')->insert([
            'name' => $request->name,
            'description' => $request->description,
            'price' => $request->price,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        if($products){
            return response()->json([
                'code' => 200,
                'message' => 'Product Create Successfully',
                'status' => true,
                'error' => false,
            ]);
        }else{
            return response()->json([
                'code' => 201,
                'message' => 'Oops Something error',
                'status' => false,
                'error' => true,
            ]);
        }
    }
        
   }
   
   public function show($id){
    $data=DB::table('product')->where('id',$id)->first();
    if($data){
        return response()->json([
            'code' => 200,
            'message' => 'Data Found Sucess For This '.$id,
            'status' => true,
            'error' => false,
            "data"=> $data
        ]);
    }else{
        return response()->json([
            'code' => 201,
            'message' => 'Data Not Found for This '.$id,
            'status' => false,
            'error' => true,
        ]);
    }
   }
   public function update(Request $request){
   

    $data=DB::table('product')->where('id',$request->id)->update([
        "name" => $request->name,
        "description" => $request->description,
        "price" => $request->price,
        'email' => $request->email,
        'password' => Hash::make($request->password),
    ]);

    if($data){
        return response()->json([
            'code' => 200,
            'message' => 'Product Updated Successfully',
            'status' => true,
            'error' => false,
        ]);

    }else{
        return response()->json([
            'code' => 201,
            'message' => 'Data not Updated',
            'status' => false,
            'error' => true,
        ]);

    }
}

   public function destory($id){
        $data=DB::table('product')->where('id',$id)->delete();
        if($data){
            return response()->json([
                'code' => 200,
                'message' => 'Product Deleted Successfully',
                'status' => true,
                'error' => false,
            ]);

        }else{
            
            return response()->json([
                'code' => 201,
                'message' => 'Data not Deleted',
                'status' => false,
                'error' => true,
            ]);
        }
   }

   public function signup(Request $request){

    $user=User::create([
        "name" => $request->name,
        "email" => $request->email,
        "password" => bcrypt($request->password)
    ]);
    $success['token']=$user->createToken('App')->plainTextToken;

       return response()->json([
        "message" => "User Create Successfully.",
        "data" => $success
       ]);
      
   }

   public function login(Request $request){

        $data=User::where('email',$request->email)->first();
        if($data){

            if(Hash::check($request->password, $data->password)){
                $success['token']=$data->createToken('App')->plainTextToken;
                return response()->json([
                    'code' => 200,
                    'message' => 'Login Successfully..',
                    "result"=>$success
                ]);

            }else{

                return response()->json([
                    'code' => 201,
                    'message' => 'Please Try Again',
                    'status' => false,
                    'error' => true,
                ]);
            }
            
        }else{
            return response()->json([
                'code' => 201,
                'message' => 'Email Does Not Exist',
                'status' => false,
                'error' => true,
            ]);
        }
   }

//    public function logout(Request $request){
//         $d=$request->session()->flush();
//         if($d){
//             return response()->json([
//                 'message' => 'Logout Success',
//             ]);
//         }else{
//             return response()->json([
//                 'message' => 'error',
//             ]);
//         }
//    }
   public function demo(Request $request){

        $data=Http::get('http://localhost:8000/api/products');
      
        dd($data);
        return view('demo',compact('products'));
   }
}
