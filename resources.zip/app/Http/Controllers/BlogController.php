<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BlogController extends Controller
{
    public function index(){
        $blogs=DB::table('blog')->get();
       
        return view('blog.blog', compact('blogs'));
    }

    public function store(Request $request){
        if ($request->file('img')) {
            $file = $request->img;
            $file_name = rand(111, 999) . $file->getClientOriginalName();

            // Move file to public path
            $file->move(public_path('public'), $file_name);

            // Insert data into the 'blog' table
            $data = DB::table('blog')->insert([
                "name" => $request->name,
                "img" => $file_name,
            ]);

            if ($data) {
                // Flash a success message to session
                session()->flash('message', 'Blog post created successfully!');
                session()->flash('alert-class', 'alert-success');
            } else {
                // Flash an error message to session
                session()->flash('message', 'Error creating blog post.');
                session()->flash('alert-class', 'alert-danger');
            }
        }

        // Redirect back to the blog creation form
        return redirect()->back();
    }

    public function show(){
        return view('show');
    }
}
